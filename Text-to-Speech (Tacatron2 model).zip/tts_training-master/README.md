<h1> Text to Speech training </h1>

This repository contains the code for training tacotron 2 model


sudo apt-get install python3-dev
pip install -r requirements.txt